# Bot Auto Share Message Telegram

Bot ini secara otomatis membagikan pesan dari pengguna ke grup atau channel tertentu di Telegram dengan delay yang dapat diatur.

## 📁 Struktur File
